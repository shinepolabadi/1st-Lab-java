import java.util.*;

public class Abx2 {
    static int Integertoint(Integer I){
        System.out.println("Before unboxing datatype is :"+I.getClass().getSimpleName());
        return I;
    }

    public static void main(String args[]){
        Scanner sc= new Scanner(System.in);
        System.out.print("Enter integer:");
        int n = sc.nextInt();
        

    }
}
