public class autobox1 {
    public static void main(String[] args) {
        Integer I = 10;  //AutoBoxing
        int i = I;       //AutoUnboxing
        System.out.println("Vlaues of Integer object and datatype int are "+I+" and  "+i);
    }
}
